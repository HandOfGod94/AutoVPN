local function payload__3econn_names(payload_content)
  local tbl_17_auto = {}
  local i_18_auto = #tbl_17_auto
  for _, v in ipairs(payload_content) do
    local val_19_auto
    do
      local t_1_ = v
      if (nil ~= t_1_) then
        t_1_ = (t_1_).UserDefinedName
      else
      end
      val_19_auto = t_1_
    end
    if (nil ~= val_19_auto) then
      i_18_auto = (i_18_auto + 1)
      do end (tbl_17_auto)[i_18_auto] = val_19_auto
    else
    end
  end
  return tbl_17_auto
end
local function conn_names__3emenubar_items(conn_names)
  local tbl_17_auto = {}
  local i_18_auto = #tbl_17_auto
  for _, conn_name in ipairs(conn_names) do
    local val_19_auto = {title = ("Connect to " .. conn_name)}
    if (nil ~= val_19_auto) then
      i_18_auto = (i_18_auto + 1)
      do end (tbl_17_auto)[i_18_auto] = val_19_auto
    else
    end
  end
  return tbl_17_auto
end
local function load_vpn_menus()
  local vpn_config_file = hs.settings.get("vpn-config-file")
  if not (nil == vpn_config_file) then
    local config_file = io.open(vpn_config_file)
    local function close_handlers_10_auto(ok_11_auto, ...)
      config_file:close()
      if ok_11_auto then
        return ...
      else
        return error(..., 0)
      end
    end
    local function _6_()
      local function _8_()
        local t_7_ = hs.plist.readString(string.match(config_file:read("*a"), "(<plist.*</plist>)"))
        if (nil ~= t_7_) then
          t_7_ = (t_7_).PayloadContent
        else
        end
        return t_7_
      end
      return conn_names__3emenubar_items(payload__3econn_names(_8_()))
    end
    return close_handlers_10_auto(_G.xpcall(_6_, (package.loaded.fennel or debug).traceback))
  else
    return nil
  end
end
local function set_mobileconfig_file(_keys, _menuitem)
  local _let_11_ = hs.dialog.chooseFileOrFolder("Please select .mobileconfig file")
  local config_file = _let_11_["1"]
  print(("VPN config file " .. hs.inspect(config_file)))
  return hs.settings.set("vpn-config-file", config_file)
end
local function set_auth_token(_keys, _menuitem)
  local _, vpn_auth_token = hs.dialog.textPrompt("Auth Token", "Enter auth token to generate otp from")
  print(("Auth Token" .. hs.inspect(vpn_auth_token)))
  return hs.settings.set("vpn-auth-token", vpn_auth_token)
end
local function init()
  local menubar = hs.menubar.new()
  local static_menu = {{title = "-"}, {title = "Edit Preferences", menu = {{title = "Set .mobileconfig file", fn = set_mobileconfig_file}, {title = "Set auth token", fn = set_auth_token}}}}
  menubar:setTitle("AutoVPN")
  return menubar:setMenu(hs.fnutils.concat(load_vpn_menus(), static_menu))
end
return {init = init}
