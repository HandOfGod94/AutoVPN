local function init()
  local menubar = hs.menubar.new()
  return menubar:setTitle("AutoVPN")
end
return {init = init}
